public class MecanicoDAO {
}