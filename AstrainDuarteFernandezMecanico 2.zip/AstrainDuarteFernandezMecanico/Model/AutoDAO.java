public class AutoDAO {
}