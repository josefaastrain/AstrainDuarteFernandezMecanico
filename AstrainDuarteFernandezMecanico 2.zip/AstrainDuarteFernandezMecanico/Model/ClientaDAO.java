public class ClienteDAO {
}