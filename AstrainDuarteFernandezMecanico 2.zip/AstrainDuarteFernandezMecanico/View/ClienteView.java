public class ClienteView {
}